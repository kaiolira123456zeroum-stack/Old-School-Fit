import { ThemeView } from '../views/ThemeView.js';

export class ThemeController {
  static toggleTheme() {
    document.body.classList.toggle("dark");

    const tema = document.body.classList.contains("dark")
      ? "dark"
      : "light";

    localStorage.setItem("theme", tema);
    ThemeView.atualizarTexto();
  }

  static initTheme() {
    const temaSalvo = localStorage.getItem("theme");

    if (temaSalvo === "dark") {
      document.body.classList.add("dark");
    }

    ThemeView.atualizarTexto();
  }
}