// Importações
import { Pessoa } from './models/Pessoa.js';
import { Funcionario } from './models/Funcionario.js';
import { Admin } from './models/Admin.js';
import { SuperAdmin } from './models/SuperAdmin.js';
import { Cliente } from './models/Cliente.js';
import { Controller } from './controllers/Controller.js';
import { ThemeController } from './utils/ThemeController.js';

// Inicializar tema
ThemeController.initTheme();

// Tornar o controller disponível globalmente
const controller = new Controller();
window.controller = controller;

// Tornar classes disponíveis globalmente para os HTMLs
window.Pessoa = Pessoa;
window.Funcionario = Funcionario;
window.Admin = Admin;
window.SuperAdmin = SuperAdmin;
window.Cliente = Cliente;

// Função para alternar tema (mantida para compatibilidade)
window.toggleTheme = ThemeController.toggleTheme;

// Dados de exemplo pré-cadastrados para teste
window.exemplos = {
  cliente: new Cliente("Maria Silva", "maria@email.com", "(11) 98765-4321", 150),
  funcionario: new Funcionario("Carlos Santos", "carlos@empresa.com", "(11) 91234-5678", "Analista"),
  admin: new Admin("Ana Oliveira", "ana@admin.com", "(11) 99876-5432", "Gerente", "Alto"),
  superadmin: new SuperAdmin("Roberto Alves", "roberto@superadmin.com", "(11) 97777-8888", "Diretor", "Máximo")
};

// Adicionar alguns dados de exemplo aos objetos
window.exemplos.cliente.registrarCompra("Notebook", 2500.00);
window.exemplos.cliente.registrarCompra("Mouse", 89.90);

window.exemplos.funcionario.adicionarProjeto("Sistema de Gestão");
window.exemplos.funcionario.registrarHoras(40);

window.exemplos.admin.banirUsuario("Usuário Teste 1");
window.exemplos.admin.banirUsuario("Usuário Teste 2");
window.exemplos.admin.registrarLog("Sistema inicializado");