import { Pessoa } from './Pessoa.js';

export class Cliente extends Pessoa {
  constructor(nome, email, telefone, pontos) {
    super(nome, email, telefone);
    this.pontos = pontos;
    this.comprasRealizadas = [];
    this.ultimaCompra = null;
  }

  baterPonto() {
    return `${this.nome} bateu o ponto com sucesso.`;
  }

  visualizarPontos() {
    return `${this.nome} possui ${this.pontos} pontos.`;
  }

  // Visualizar histórico de compras
  visualizarCompras() {
    if (this.comprasRealizadas.length === 0) {
      return `${this.nome} ainda não realizou nenhuma compra.`;
    }
    
    let historico = `<strong>Histórico de Compras de ${this.nome}:</strong><br>`;
    this.comprasRealizadas.forEach((compra, index) => {
      historico += `${index + 1}. ${compra.produto} - R$ ${compra.valor.toFixed(2)} (${compra.data})<br>`;
    });
    
    return historico;
  }

  // Registrar uma nova compra
  registrarCompra(produto, valor) {
    const compra = {
      produto: produto,
      valor: valor,
      data: new Date().toLocaleDateString('pt-BR')
    };
    
    this.comprasRealizadas.push(compra);
    this.ultimaCompra = compra.data;
    
    // Adicionar pontos baseados no valor da compra (1 ponto por cada R$10)
    const pontosAdicionados = Math.floor(valor / 10);
    this.pontos += pontosAdicionados;
    
    return `${this.nome} realizou a compra de ${produto} por R$ ${valor.toFixed(2)}. Ganhou ${pontosAdicionados} pontos!`;
  }

  // Solicitar suporte
  solicitarSuporte(assunto) {
    return `${this.nome} solicitou suporte sobre: "${assunto}". Ticket criado: #${Math.floor(Math.random() * 10000)}`;
  }
}