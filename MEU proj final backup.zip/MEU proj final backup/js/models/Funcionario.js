import { Pessoa } from './Pessoa.js';

export class Funcionario extends Pessoa {
  #cargo;
  #salario;

  constructor(nome, email, telefone, cargo) {
    super(nome, email, telefone);
    this.cargo = cargo;
    this.#salario = 0;
    this.horasTrabalhadas = 0;
    this.projetos = [];
  }

  get cargo() {
    return this.#cargo;
  }

  set cargo(novoCargo) {
    if (!novoCargo) return;
    this.#cargo = novoCargo;
  }

  // Getter e setter para salário
  get salario() {
    return this.#salario;
  }

  set salario(novoSalario) {
    if (novoSalario >= 0) {
      this.#salario = novoSalario;
    }
  }

  // Registrar horas trabalhadas
  registrarHoras(horas) {
    if (horas > 0) {
      this.horasTrabalhadas += horas;
      return `${this.nome} registrou ${horas} horas de trabalho. Total: ${this.horasTrabalhadas} horas.`;
    }
    return "Horas inválidas.";
  }

  // Visualizar horas trabalhadas
  visualizarHorasTrabalhadas() {
    return `${this.nome} trabalhou ${this.horasTrabalhadas} horas este mês.`;
  }

  // Adicionar projeto
  adicionarProjeto(projeto) {
    this.projetos.push(projeto);
    return `${this.nome} foi designado para o projeto: ${projeto}`;
  }

  // Listar projetos
  listarProjetos() {
    if (this.projetos.length === 0) {
      return `${this.nome} não está em nenhum projeto no momento.`;
    }
    
    let lista = `<strong>Projetos de ${this.nome}:</strong><br>`;
    this.projetos.forEach((projeto, index) => {
      lista += `${index + 1}. ${projeto}<br>`;
    });
    
    return lista;
  }
}