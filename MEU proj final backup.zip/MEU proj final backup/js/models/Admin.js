import { Funcionario } from './Funcionario.js';

export class Admin extends Funcionario {
  #nivelAcesso;
  #usuariosBanidos;

  constructor(nome, email, telefone, cargo, nivelAcesso) {
    super(nome, email, telefone, cargo);
    this.nivelAcesso = nivelAcesso;
    this.#usuariosBanidos = [];
    this.logsSistema = [];
  }

  get nivelAcesso() {
    return this.#nivelAcesso;
  }

  set nivelAcesso(nivel) {
    if (!nivel) return;
    this.#nivelAcesso = nivel;
  }

  // Getter para usuários banidos
  get usuariosBanidos() {
    return [...this.#usuariosBanidos]; // Retorna cópia para proteger os dados
  }

  gerenciarSistema() {
    this.registrarLog("Sistema acessado para gerenciamento");
    return `${this.nome} está gerenciando o sistema.`;
  }

  banirUsuario(usuario) {
    if (usuario && usuario.trim() !== "") {
      this.#usuariosBanidos.push({
        nome: usuario.trim(),
        data: new Date().toLocaleString('pt-BR'),
        admin: this.nome
      });
      
      this.registrarLog(`Usuário "${usuario}" banido por ${this.nome}`);
      return `O(a) ${usuario.trim()} foi banido(a).`;
    }
    return "Nome de usuário inválido.";
  }

  // Desbanir usuário
  desbanirUsuario(usuario) {
    const index = this.#usuariosBanidos.findIndex(u => u.nome === usuario);
    
    if (index !== -1) {
      this.#usuariosBanidos.splice(index, 1);
      this.registrarLog(`Usuário "${usuario}" desbanido por ${this.nome}`);
      return `O(a) ${usuario} foi desbanido(a).`;
    }
    
    return "Usuário não encontrado na lista de banidos.";
  }

  // Listar usuários banidos
  listarUsuariosBanidos() {
    if (this.#usuariosBanidos.length === 0) {
      return "Nenhum usuário banido no momento.";
    }
    
    let lista = `<strong>Usuários Banidos:</strong><br>`;
    this.#usuariosBanidos.forEach((usuario, index) => {
      lista += `${index + 1}. ${usuario.nome} (Banido em: ${usuario.data} por ${usuario.admin})<br>`;
    });
    
    return lista;
  }

  // Registrar log do sistema
  registrarLog(acao) {
    const log = {
      acao: acao,
      data: new Date().toLocaleString('pt-BR'),
      admin: this.nome
    };
    
    this.logsSistema.push(log);
    
    // Manter apenas os últimos 100 logs
    if (this.logsSistema.length > 100) {
      this.logsSistema.shift();
    }
  }

  // Visualizar logs do sistema
  visualizarLogs() {
    if (this.logsSistema.length === 0) {
      return "Nenhum log registrado no sistema.";
    }
    
    let logs = `<strong>Logs do Sistema (últimos ${this.logsSistema.length}):</strong><br>`;
    this.logsSistema.forEach((log, index) => {
      logs += `${index + 1}. [${log.data}] ${log.acao}<br>`;
    });
    
    return logs;
  }

  // Criar backup do sistema
  criarBackup() {
    this.registrarLog("Backup do sistema criado");
    const backupCode = `BACKUP-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
    return `Backup criado com sucesso! Código: ${backupCode}`;
  }
}