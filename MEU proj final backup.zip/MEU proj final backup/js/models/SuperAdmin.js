import { Admin } from './Admin.js';

export class SuperAdmin extends Admin {
  constructor(nome, email, telefone, cargo, nivelAcesso) {
    super(nome, email, telefone, cargo, nivelAcesso);
  }

  resetarSistema() {
    this.registrarLog("SISTEMA RESETADO - Ação realizada por SuperAdmin");
    return `${this.nome} resetou o sistema. Todos os logs foram limpos (exceto este).`;
  }

  // Visualizar estatísticas do sistema
  visualizarEstatisticas() {
    const stats = {
      totalLogs: this.logsSistema.length,
      usuariosBanidos: this.usuariosBanidos.length,
      dataHora: new Date().toLocaleString('pt-BR'),
      superAdmin: this.nome
    };
    
    return `
      <strong>Estatísticas do Sistema:</strong><br>
      • Total de Logs: ${stats.totalLogs}<br>
      • Usuários Banidos: ${stats.usuariosBanidos}<br>
      • Data/Hora: ${stats.dataHora}<br>
      • SuperAdmin Ativo: ${stats.superAdmin}
    `;
  }

  // Configurações avançadas do sistema
  configurarSistema(config) {
    this.registrarLog(`Configurações do sistema alteradas por ${this.nome}: ${JSON.stringify(config)}`);
    return `Configurações do sistema atualizadas com sucesso por ${this.nome}`;
  }
}