export class Pessoa {
  #nome;
  #email;
  #telefone;
  #dataDeCadastro;

  constructor(nome, email, telefone) {
    this.#nome = nome;
    this.#email = email;
    this.#telefone = telefone;
    this.#dataDeCadastro = new Date().toLocaleDateString();
  }

  // Getters
  get nome() {
    return this.#nome;
  }

  get email() {
    return this.#email;
  }

  get telefone() {
    return this.#telefone;
  }

  get dataDeCadastro() {
    return this.#dataDeCadastro;
  }

  // Setters com validação
  set email(novoEmail) {
    if (!novoEmail.includes("@")) {
      console.error("Email inválido!");
      return;
    }
    this.#email = novoEmail;
  }

  set telefone(novoTelefone) {
    if (novoTelefone.trim() === "") {
      console.error("Telefone inválido!");
      return;
    }
    this.#telefone = novoTelefone;
  }

  exibirInformacao() {
    return `
      Nome: ${this.#nome}<br>
      Email: ${this.#email}<br>
      Telefone: ${this.#telefone}<br>
      Data de Cadastro: ${this.#dataDeCadastro}
    `;
  }
}
