export class Controller {
  constructor() {
    this.pessoa = null;
  }

  setPessoa(pessoa) {
    this.pessoa = pessoa;
    import('../views/View.js').then(({ View }) => {
      View.exibirInformacao(pessoa);
      View.exibirAcao(pessoa);
    });
  }

  // ========== MÉTODOS DO CLIENTE ==========
  baterPonto() {
    if (this.pessoa && this.pessoa.baterPonto) {
      alert(this.pessoa.baterPonto());
    }
  }

  visualizarPontos() {
    if (this.pessoa && this.pessoa.visualizarPontos) {
      alert(this.pessoa.visualizarPontos());
    }
  }

  visualizarCompras() {
    if (this.pessoa && this.pessoa.visualizarCompras) {
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px;">
          ${this.pessoa.visualizarCompras()}
        </div>
      `;
    }
  }

  solicitarSuporte() {
    if (this.pessoa && this.pessoa.solicitarSuporte) {
      const assunto = prompt("Descreva o motivo do seu suporte:");
      if (assunto && assunto.trim() !== "") {
        alert(this.pessoa.solicitarSuporte(assunto));
      }
    }
  }

  registrarCompra() {
    if (this.pessoa && this.pessoa.registrarCompra) {
      const produto = prompt("Nome do produto:");
      if (!produto || produto.trim() === "") {
        alert("Nome do produto é obrigatório!");
        return;
      }
      
      const valorStr = prompt("Valor da compra (R$):");
      const valor = parseFloat(valorStr);
      
      if (isNaN(valor) || valor <= 0) {
        alert("Valor inválido!");
        return;
      }
      
      alert(this.pessoa.registrarCompra(produto, valor));
      
      // Atualizar a exibição
      import('../views/View.js').then(({ View }) => {
        View.exibirInformacao(this.pessoa);
      });
    }
  }

  // ========== MÉTODOS DO FUNCIONÁRIO ==========
  registrarHoras() {
    if (this.pessoa && this.pessoa.registrarHoras) {
      const horasStr = prompt("Quantas horas você trabalhou?");
      const horas = parseFloat(horasStr);
      
      if (isNaN(horas) || horas <= 0) {
        alert("Horas inválidas!");
        return;
      }
      
      alert(this.pessoa.registrarHoras(horas));
    }
  }

  visualizarHoras() {
    if (this.pessoa && this.pessoa.visualizarHorasTrabalhadas) {
      alert(this.pessoa.visualizarHorasTrabalhadas());
    }
  }

  listarProjetos() {
    if (this.pessoa && this.pessoa.listarProjetos) {
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px;">
          ${this.pessoa.listarProjetos()}
        </div>
      `;
    }
  }

  adicionarProjeto() {
    if (this.pessoa && this.pessoa.adicionarProjeto) {
      const projeto = prompt("Nome do novo projeto:");
      if (projeto && projeto.trim() !== "") {
        alert(this.pessoa.adicionarProjeto(projeto));
      }
    }
  }

  // ========== MÉTODOS DO ADMIN ==========
  gerenciarSistema() {
    if (this.pessoa && this.pessoa.gerenciarSistema) {
      alert(this.pessoa.gerenciarSistema());
    }
  }

 banirUsuario() {
  if (this.pessoa && this.pessoa.banirUsuario) {
    const usuario = prompt("Quem você quer banir?", "João");
    
    if (usuario && usuario.trim() !== "") {
      const resultado = this.pessoa.banirUsuario(usuario);
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px; background-color: #ffebee; border-left: 4px solid #f44336; color: #721c24;">
          <strong>${resultado}</strong>
        </div>
      `;
    } else {
      alert("Operação cancelada ou nome inválido.");
    }
  }
}

desbanirUsuario() {
  if (this.pessoa && this.pessoa.desbanirUsuario) {
    const usuario = prompt("Quem você quer desbanir?");
    
    if (usuario && usuario.trim() !== "") {
      const resultado = this.pessoa.desbanirUsuario(usuario);
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px; background-color: #e8f5e9; border-left: 4px solid #4caf50; color: #155724;">
          <strong>${resultado}</strong>
        </div>
      `;
    }
  }
}

  listarUsuariosBanidos() {
    if (this.pessoa && this.pessoa.listarUsuariosBanidos) {
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px;">
          ${this.pessoa.listarUsuariosBanidos()}
        </div>
      `;
    }
  }

  visualizarLogs() {
    if (this.pessoa && this.pessoa.visualizarLogs) {
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px; max-height: 300px; overflow-y: auto;">
          ${this.pessoa.visualizarLogs()}
        </div>
      `;
    }
  }

  criarBackup() {
    if (this.pessoa && this.pessoa.criarBackup) {
      alert(this.pessoa.criarBackup());
    }
  }

  // ========== MÉTODOS DO SUPERADMIN ==========
  resetarSistema() {
    if (this.pessoa && this.pessoa.resetarSistema) {
      const confirmacao = confirm("Tem certeza que deseja resetar o sistema? Esta ação não pode ser desfeita!");
      
      if (confirmacao) {
        alert(this.pessoa.resetarSistema());
      }
    }
  }

  visualizarEstatisticas() {
    if (this.pessoa && this.pessoa.visualizarEstatisticas) {
      document.getElementById("acao").innerHTML += `
        <div class="card" style="margin-top: 20px; padding: 15px;">
          ${this.pessoa.visualizarEstatisticas()}
        </div>
      `;
    }
  }

  configurarSistema() {
    if (this.pessoa && this.pessoa.configurarSistema) {
      const config = prompt("Digite as configurações do sistema (formato JSON):", '{"manutencao": false, "novosUsuarios": true}');
      
      if (config) {
        try {
          const configObj = JSON.parse(config);
          alert(this.pessoa.configurarSistema(configObj));
        } catch (e) {
          alert("JSON inválido!");
        }
      }
    }
  }
}