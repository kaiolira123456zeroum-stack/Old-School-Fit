export class ThemeView {
  static atualizarTexto() {
    const btn = document.getElementById("themeToggle");
    if (!btn) return;

    btn.innerText = document.body.classList.contains("dark")
      ? "🔆 Tema Claro"
      : "🌙 Tema Escuro";
  }
}