export class View {
  static exibirInformacao(pessoa) {
    document.getElementById("info").innerHTML = pessoa.exibirInformacao();
  }

  static exibirAcao(pessoa) {
    const acao = document.getElementById("acao");
    acao.innerHTML = "";

    // Importar classes para verificação de instância
    import('../models/Cliente.js').then(({ Cliente }) => {
      import('../models/Funcionario.js').then(({ Funcionario }) => {
        import('../models/Admin.js').then(({ Admin }) => {
          import('../models/SuperAdmin.js').then(({ SuperAdmin }) => {
            
            // Ações para Cliente
            if (pessoa instanceof Cliente) {
              acao.innerHTML += `
                <button onclick="controller.baterPonto()">Bater Ponto</button>
                <button onclick="controller.visualizarPontos()">Visualizar Pontos</button>
                <button onclick="controller.visualizarCompras()">Histórico de Compras</button>
                <button onclick="controller.solicitarSuporte()">Solicitar Suporte</button>
                <button onclick="controller.registrarCompra()">Registrar Compra</button>
              `;
            }

            // Ações para Funcionário (não admin)
            if (pessoa instanceof Funcionario && !(pessoa instanceof Admin)) {
              acao.innerHTML += `
                <button onclick="controller.registrarHoras()">Registrar Horas</button>
                <button onclick="controller.visualizarHoras()">Ver Horas Trabalhadas</button>
                <button onclick="controller.listarProjetos()">Listar Projetos</button>
                <button onclick="controller.adicionarProjeto()">Adicionar Projeto</button>
              `;
            }

            // Ações para Admin (não SuperAdmin)
            if (pessoa instanceof Admin && !(pessoa instanceof SuperAdmin)) {
              acao.innerHTML += `
                <button onclick="controller.gerenciarSistema()">Gerenciar Sistema</button>
                <button onclick="controller.banirUsuario()">Banir Usuário</button>
                <button onclick="controller.desbanirUsuario()">Desbanir Usuário</button>
                <button onclick="controller.listarUsuariosBanidos()">Ver Banidos</button>
                <button onclick="controller.visualizarLogs()">Ver Logs do Sistema</button>
                <button onclick="controller.criarBackup()">Criar Backup</button>
              `;
            }

            // Ações para SuperAdmin 
            if (pessoa instanceof SuperAdmin) {
              acao.innerHTML += `
                <button onclick="controller.resetarSistema()">Resetar Sistema</button>
                <button onclick="controller.visualizarEstatisticas()">Estatísticas do Sistema</button>
                <button onclick="controller.configurarSistema()">Configurar Sistema</button>
                <br>
                <button onclick="controller.banirUsuario()">Banir Usuário</button>
                <button onclick="controller.desbanirUsuario()">Desbanir Usuário</button>
                <button onclick="controller.listarUsuariosBanidos()">Ver Banidos</button>
                <button onclick="controller.visualizarLogs()">Ver Logs do Sistema</button>
                <button onclick="controller.criarBackup()">Criar Backup</button>
              `;
            }

            // Link para voltar ao início (aparece em todas as páginas)
            acao.innerHTML += `
              <br><br>
              <a href="index.html">Voltar ao início</a>
            `;
          });
        });
      });
    });
  }
}